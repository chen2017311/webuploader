import {Dispatcher} from 'flux'
var AppDispatcher = new Dispatcher();
import ListStore from '../store/ListStore'

//注册过的，才可以被action分发到,action 被分发过来的参数
AppDispatcher.register(function(action){
    switch (action.actionType){
        case 'ADD_NEW_ITEM':
            //调用store的add
            ListStore.addNewItem(action.text);
            //push后，通过自定义事件，更新视图
            ListStore.onChange();
            break;
        default:
            break;
    }
})







export default AppDispatcher