import {EventEmitter} from 'events'; //事件监听和发射
import assign from 'object-assign'; //整合对象

//把当前对象和事件监听发射插件整合
export default assign({},EventEmitter.prototype,{
    list : [1,2,3,4,5,6],
    getAll(){
        return this.list;
    },
    addNewItem(text){
        this.list.push(text)
    },
    onChange(){
        this.emit('change')
    },
    //我已经改完数据了，你重新获取后，再渲染
    addChangeListener(callback){
        this.on('change',callback)
    },
    removeChangeListener(callback){
        this.removeListener(callback)
    }
})