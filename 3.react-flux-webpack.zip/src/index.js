
import React from 'react';
import ReactDOM from 'react-dom';
import MyListController from './components/MyListController.jsx';



ReactDOM.render(
    <MyListController/>,
    document.getElementById('app')
)