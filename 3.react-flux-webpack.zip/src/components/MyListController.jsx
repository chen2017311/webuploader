

import React from 'react';
import MyList from './MyList.jsx';
import ListStore from '../store/ListStore';
import listActions from '../actions/listActions';

export default class MyListController extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            list :  ListStore.getAll()
        }
        this._onChange = this._onChange.bind(this);
        this._newAddItem = this._newAddItem.bind(this)
    }
    componentDidMount(){
        ListStore.addChangeListener(this._onChange)
    }
    componentWillUnmount(){
        ListStore.removeChangeListener(this._onChange)
    }
    _onChange(){
        this.setState({
            list : ListStore.getAll()
        })
    }
    _newAddItem(){
        listActions.newAddItem('new Item');
    }
    render(){
        var items = this.state.list;
       return (
           <MyList items={items} newAddItem={this._newAddItem}/>
       )
    }
}