
import React from 'react';


export default function(props){
    var items = props.items;
    var itemHtml = items.map(function(item,i){
        return <li key={i}>{item}</li>
    })

    return(
        <div>
            <ul>
                {itemHtml}
            </ul>
            <button onClick={props.newAddItem}>new item</button>
        </div>


    )
}