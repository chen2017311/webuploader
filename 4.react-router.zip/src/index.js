
import React from 'react';
import { render } from  'react-dom';
import { Router, Route, hashHistory,IndexRoute } from 'react-router';
import routess from './routes.config';


var routes = <Route path="/" component={routess.App}>
                {/*默认页面*/}
                <IndexRoute component={routess.Home}/>
                <Route path="/repos" component={routess.Repos}>
                    <Route path="/repos/:userName/:repoName" component={routess.Repo}/>
                </Route>
                <Route path="/about" component={routess.About}/>
            </Route>
render(
    <Router routes={routes} history={hashHistory}/>
    ,
        document.getElementById('app')
)