import React from 'react';

export default class Home1 extends React.Component{

    render(){
        return(
            <div>Home</div>
        )
    }
}