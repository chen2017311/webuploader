import React from 'react';
import {Link} from 'react-router'
export default class Repos extends React.Component{

    render(){
        return(
            <div>
                <h2>Repos</h2>
                <ul>
                    <li>
                        <Link to="/repos/reactjs/react-router">react-router</Link>
                    </li>
                    <li>
                        <Link to="/repos/fackbook/react">react</Link>
                    </li>
                </ul>
                {this.props.children}
            </div>
        )
    }
}