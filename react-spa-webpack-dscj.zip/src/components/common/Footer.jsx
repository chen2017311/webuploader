import React from 'react';
import './footer.css'

export default class Footer extends React.Component{
    constructor(props){
        super(props);

    }

    render(){

        return(
            <div className="dirWrap">footer
                <div className="footerText">
                    <span>北京迪殊科技有限公司 版权所有 ｜京ICP备16000644号</span>
                </div>
            </div>
        )
    }
}