import React from 'react';

export default class Trends extends React.Component{
    constructor(props){
        super(props);

    }
    render(){
        return(
            <div>点师动态</div>
        )
    }
}