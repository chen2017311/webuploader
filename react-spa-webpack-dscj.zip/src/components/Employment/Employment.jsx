import React from 'react';


export default class Employment extends React.Component{
    constructor(props){
        super(props);

    }

    render(){
        return(
            <div>明日之星就业班</div>
        )
    }
}