import React from 'react';


export default class Class extends React.Component{
    constructor(props){
        super(props);

    }

    render(){
        return(
            <div>服务条款</div>
        )
    }
}