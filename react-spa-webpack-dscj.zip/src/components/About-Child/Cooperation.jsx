import React from 'react';


export default class Class extends React.Component{
    constructor(props){
        super(props);

    }

    render(){
        return(
            <div>企业合作</div>
        )
    }
}