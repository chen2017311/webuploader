import React from 'react';
import NavLink from '../NavLink.jsx';
import './App.css';
import Footer from './common/Footer.jsx';
export default class App extends React.Component{

    constructor(props){
        super(props);

    }

    render(){
        return (
            <div>
                <div className="menu">
                    <NavLink to="/">
                        <span>
                            <img src="src/assets/logo.png" alt="logo"/>
                        </span>
                    </NavLink>
                    <ul className="menu_ul">
                        <li><NavLink to="/" onlyActiveOnIndex>首页</NavLink></li>
                        <li><NavLink to="/about">关于我们</NavLink></li>
                        <li><NavLink to="/class">大咖公开课</NavLink></li>
                        <li><NavLink to="/employment">明日之星就业班</NavLink></li>
                        <li><NavLink to="/trends">点师动态</NavLink></li>
                    </ul>
                </div>
                <div className="divStyle">
                    {this.props.children}
                </div>
                <div className="footer">
                    <Footer></Footer>
                </div>
            </div>
        )
    }
}